Placeholder file of the Smartstore demo shop.
This is where the purchased software would be.
The licence agreement is shown before the download.