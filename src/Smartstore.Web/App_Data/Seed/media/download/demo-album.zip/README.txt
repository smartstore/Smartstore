Placeholder file of the Smartstore demo shop.
This is where the purchased album would be.